import { useState } from 'react';
import Blog from '../Blog/Blog';

import './App.css'





function App() {
  const [counter,setCounter] = useState(0);
  const [user,setUser] = useState({
    username: "prueba",
    email: "prueba@mail.com"
  })
  function handleClick(id) {
    console.log("hola " + id);
  }
  function handleCounter(){
    setCounter(prevCounter => prevCounter + 1);
  }
  return (
    <>
      <Blog />

    </>
  )
}

export default App
