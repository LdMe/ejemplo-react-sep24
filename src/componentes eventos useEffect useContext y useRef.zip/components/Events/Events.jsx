import { useState, useEffect, useRef,useContext } from 'react';

import { LanguageContext } from '../../context/languageContext';
import { getEvents as getEventsFromApi } from '../../utils/api';
import EventCard from '../EventCard/EventCard';
import texts from '../../utils/language';



function Events() {
  const [events, setEvents] = useState([]);
  const [page,setPage] = useState(1);
  const renderRef = useRef(0);
  const lastElementRef = useRef(null);
  const {language,toggleLanguage} = useContext(LanguageContext);

  useEffect(() => {
    getEvents(page);
  }, [page]);

  useEffect(()=>{
    lastElementRef.current.scrollIntoView({behavior: "smooth"});
  },[events])

  useEffect(() => {
    renderRef.current = renderRef.current + 1;
    console.log(renderRef.current);
  })
  async function getEvents(page) {
    const data = await getEventsFromApi(page);
    console.log(data);
    const items = data?.items ? data.items : [];
    setEvents(items);
  }
  function handleNextPage(){
    getEvents(page +1);
    setPage(oldPage=>oldPage+1)
  }

  return (
    <>
    <button onClick={toggleLanguage}>{language=== "Es" ? "Euskara": "Castellano"}</button>
      <h1>{texts["title"][language]}</h1>
      {events.length === 0 && (
        <h2>{texts["loading"][language]}...</h2>
      )}
      {events.length > 0 && (
        <button onClick={handleNextPage}>{texts["next"][language]}</button>
      )}
      {events.map(event => (
        <EventCard event={event} key={event.id}/>
      ))}
      <div ref={lastElementRef}/>
    </>
  )
}

export default Events
