import { useState } from 'react';
import Button from '../Button/Button'
import Form from '../Form/Form';

import './App.css'





function App() {
  const [counter,setCounter] = useState(0);
  const [user,setUser] = useState({
    username: "prueba",
    email: "prueba@mail.com"
  })
  function handleClick(id) {
    console.log("hola " + id);
  }
  function handleCounter(){
    setCounter(prevCounter => prevCounter + 1);
  }
  return (
    <>
      <div className="App">
        <Button funcionClick={handleClick} id="boton avanzar">Avanzar</Button>
        <Button funcionClick={handleClick} id="boton retroceder">Retroceder</Button>
        <Button funcionClick={handleCounter} id="boton cuenta">Cuenta</Button>
      </div>
      <p>cuenta: {counter}</p>
      <article className='user-data'>
        <p>Username: {user.username}</p>
        <p>Email: {user.email}</p>
      </article>
      <Form 
      initialUser={user} 
      onSubmit={setUser}
      />

    </>
  )
}

export default App
