import { useState } from "react";

function Form ({initialUser,onSubmit}){
    const [user,setUser] = useState(initialUser);

    function handleUsername(e){
        const newUsername = e.target.value;
        /* //incorrecto
        const newUser = {...user};
        newUser.username = newUsername;
        setUser(newUser); */
        
        setUser(oldUser => {
            const newUser = { ...oldUser };
            newUser.username = newUsername;
            return newUser;
        })
    }
    function handleEmail(e){
        const newEmail = e.target.value;
        /* //incorrecto
        const newUser = {...user};
        newUser.email = newEmail;
        setUser(newUser); */
        
        setUser(oldUser => {
            const newUser = { ...oldUser };
            newUser.email = newEmail;
            return newUser;
        })
    }
    function handleSubmit(e){
        e.preventDefault();
        onSubmit(user);
        setUser({
            username:"",
            email:""
        })
    }
    return (
        <>
            <article className="form-data">
                <p>Form username: {user.username}</p>
                <p>Form email: {user.email}</p>
            </article>
            <form onSubmit={handleSubmit}>
                <label>Username</label>
                <input
                    type="text"
                    name="username"
                    value={user.username}
                    onChange={handleUsername}
                />
                <label htmlFor="email">Email</label>
                <input
                    type="email"
                    name="email"
                    value={user.email}
                    onChange={handleEmail}
                />
                <button>Guardar</button>

            </form>
        </>
    )

}

export default Form