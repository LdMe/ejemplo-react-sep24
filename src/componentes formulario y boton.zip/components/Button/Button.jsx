
import './Button.css';

function Button({ funcionClick, id, children }) {
    return (
        <button
            onClick={() => funcionClick(id)}
            className="button"
        >
            {children}
        </button>
    );
}

export default Button;